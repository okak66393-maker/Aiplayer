package com.aiplayer.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Выполняет жесты (нажатия и свайпы) вместо пользователя. */
class TapService : AccessibilityService() {

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Блокирует поток до конца жеста. Вызывать НЕ из главного потока. */
    private fun gesture(vararg strokes: GestureDescription.StrokeDescription): Boolean {
        val b = GestureDescription.Builder()
        strokes.forEach { b.addStroke(it) }
        val latch = CountDownLatch(1)
        var ok = false
        val sent = dispatchGesture(b.build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(g: GestureDescription?) { latch.countDown() }
        }, null)
        if (!sent) return false
        latch.await(5, TimeUnit.SECONDS)
        return ok
    }

    private fun point(x: Float, y: Float) = Path().apply { moveTo(x, y) }

    fun tap(x: Float, y: Float, holdMs: Long = 60): Boolean =
        gesture(GestureDescription.StrokeDescription(point(x, y), 0, holdMs))

    fun doubleTap(x: Float, y: Float): Boolean {
        val a = tap(x, y)
        Thread.sleep(120)
        return tap(x, y) && a
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durMs: Long = 350): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return gesture(GestureDescription.StrokeDescription(p, 0, durMs.coerceAtLeast(50)))
    }

    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    companion object {
        @Volatile var instance: TapService? = null
    }
}

package com.aiplayer.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.util.DisplayMetrics
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Цикл: скриншот -> Claude -> действие -> жест. */
class AgentService : Service() {

    @Volatile private var running = false
    private var worker: Thread? = null
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val ui = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            finish("Остановлено")
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY

        startForegroundCompat(buildNotification("Подготовка…"))

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null) { finish("Нет разрешения на захват экрана"); return START_NOT_STICKY }

        val prefs = getSharedPreferences("agent", MODE_PRIVATE)
        val key = prefs.getString("key", "") ?: ""
        val model = prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        val goal = prefs.getString("goal", "") ?: ""
        val maxSteps = prefs.getInt("steps", 150)
        val provider = prefs.getString("provider", "claude") ?: "claude"

        running = true
        worker = Thread { runLoop(code, data, key, model, goal, maxSteps, provider) }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun realSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    private fun runLoop(code: Int, data: Intent, key: String, model: String, goal: String, maxSteps: Int, provider: String) {
        try {
            val (realW, realH) = realSize()
            val scale = minOf(1f, 1280f / maxOf(realW, realH))
            val iw = (realW * scale).toInt() and 1.inv()
            val ih = (realH * scale).toInt() and 1.inv()
            val density = resources.displayMetrics.densityDpi

            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(code, data)
            projection = proj
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { if (running) finish("Захват экрана остановлен") }
            }, ui)
            val rd = ImageReader.newInstance(iw, ih, PixelFormat.RGBA_8888, 2)
            reader = rd
            display = proj.createVirtualDisplay(
                "aiplayer", iw, ih, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, null
            )

            // Время, чтобы переключиться в игру.
            for (i in 5 downTo 1) {
                if (!running) return
                notify("Старт через $i с — открой игру")
                Thread.sleep(1000)
            }

            val history = ArrayList<String>()
            var fails = 0
            var step = 0
            while (running && step < maxSteps) {
                val tap = TapService.instance
                if (tap == null) { finish("Выключен доступ «Специальные возможности»"); return }

                val jpeg = grab(rd, iw, ih)
                if (jpeg == null) { Thread.sleep(500); continue }

                val reply = try {
                    ask(provider, key, model, goal, jpeg, iw, ih, history).also { fails = 0 }
                } catch (e: ApiError) {
                    if (e.fatal || ++fails >= 3) { finish("Ошибка: ${e.message}"); return }
                    Thread.sleep(4000); continue
                } catch (e: Exception) {
                    if (++fails >= 3) { finish("Сеть: ${e.message}"); return }
                    Thread.sleep(4000); continue
                }

                step++
                val action = reply.optString("action", "wait")
                val note = reply.optString("thought", "")
                notify("Шаг $step: $action — $note")
                history.add("$step. $action ${reply.optInt("x")},${reply.optInt("y")} — $note")
                if (history.size > 6) history.removeAt(0)

                fun rx(k: String) = reply.optDouble(k, 0.0).toFloat() / scale
                when (action) {
                    "tap" -> tap.tap(rx("x"), rx("y"))
                    "double_tap" -> tap.doubleTap(rx("x"), rx("y"))
                    "long_press" -> tap.tap(rx("x"), rx("y"), 900)
                    "swipe" -> tap.swipe(rx("x"), rx("y"), rx("x2"), rx("y2"))
                    "back" -> tap.back()
                    "done" -> { finish("Готово: $note"); return }
                    else -> {}
                }
                Thread.sleep(1300)
            }
            if (running) finish(if (step >= maxSteps) "Достигнут лимит шагов ($maxSteps)" else "Остановлено")
        } catch (e: InterruptedException) {
            // остановили
        } catch (e: Exception) {
            finish("Сбой: ${e.javaClass.simpleName} ${e.message}")
        }
    }

    private fun grab(rd: ImageReader, iw: Int, ih: Int): ByteArray? {
        val img = rd.acquireLatestImage() ?: return null
        try {
            val plane = img.planes[0]
            val rowPixels = plane.rowStride / plane.pixelStride
            val full = Bitmap.createBitmap(rowPixels, ih, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val bmp = if (rowPixels != iw) Bitmap.createBitmap(full, 0, 0, iw, ih) else full
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 70, out)
            return out.toByteArray()
        } finally {
            img.close()
        }
    }

    private class ApiError(msg: String, val fatal: Boolean) : Exception(msg)

    private fun ask(provider: String, key: String, model: String, goal: String, jpeg: ByteArray, iw: Int, ih: Int, history: List<String>): JSONObject {
        val system = """Ты играешь в игру на телефоне вместо человека. Тебе дают скриншот экрана размером ${iw}x${ih} пикселей (начало координат — левый верхний угол).
Цель человека: $goal

Каждый ход выбери ОДНО действие и ответь ТОЛЬКО JSON без пояснений:
{"thought":"очень коротко, что видишь и зачем","action":"tap|double_tap|long_press|swipe|back|wait|done","x":0,"y":0,"x2":0,"y2":0}
x,y — точка нажатия (для swipe — начало), x2,y2 — конец свайпа. Координаты в пикселях скриншота.
action=wait — если идёт анимация или загрузка. action=done — если цель достигнута или дальше играть нельзя.
Правила: никогда не нажимай кнопки оплаты, покупок, подтверждения платежа и не вводи пароли. Рекламу закрывай, если есть крестик, но не нажимай «установить» или «купить». Не выходи из игры без причины."""
        val hist = if (history.isEmpty()) "Это первый ход." else "Твои последние действия:\n" + history.joinToString("\n")

        val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        val or = provider == "openrouter"
        val body: JSONObject
        if (or) {
            val content = JSONArray()
                .put(JSONObject().put("type", "text").put("text", "$hist\nСледующее действие?"))
                .put(JSONObject().put("type", "image_url").put("image_url",
                    JSONObject().put("url", "data:image/jpeg;base64,$b64")))
            body = JSONObject()
                .put("model", model)
                .put("max_tokens", 300)
                .put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", content)))
        } else {
            val content = JSONArray()
                .put(JSONObject().put("type", "image").put("source", JSONObject()
                    .put("type", "base64").put("media_type", "image/jpeg").put("data", b64)))
                .put(JSONObject().put("type", "text").put("text", "$hist\nСледующее действие?"))
            body = JSONObject()
                .put("model", model)
                .put("max_tokens", 300)
                .put("system", system)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        }

        val conn = URL(if (or) "https://openrouter.ai/api/v1/chat/completions" else "https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            if (or) {
                conn.setRequestProperty("Authorization", "Bearer $key")
            } else {
                conn.setRequestProperty("x-api-key", key)
                conn.setRequestProperty("anthropic-version", "2023-06-01")
            }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val status = conn.responseCode
            val text = (if (status in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: ""
            if (status !in 200..299) {
                val msg = try { JSONObject(text).getJSONObject("error").getString("message") } catch (e: Exception) { text.take(120) }
                throw ApiError("HTTP $status: $msg", fatal = status in 400..404 && status != 429)
            }
            val j = JSONObject(text)
            val reply = if (or) j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "")
                else j.getJSONArray("content").getJSONObject(0).getString("text")
            val a = reply.indexOf('{'); val b = reply.lastIndexOf('}')
            if (a < 0 || b <= a) return JSONObject().put("action", "wait").put("thought", "не понял ответ")
            return JSONObject(reply.substring(a, b + 1))
        } finally {
            conn.disconnect()
        }
    }

    // ---- уведомление ----

    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "ИИ-игрок", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AgentService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("ИИ играет")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "СТОП", stop).build())
            .build()
    }

    private fun notify(text: String) {
        getSystemService(NotificationManager::class.java).notify(ID, buildNotification(text))
    }

    private fun startForegroundCompat(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(ID, n)
    }

    private fun finish(message: String) {
        running = false
        worker?.interrupt()
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        display = null; reader = null; projection = null
        getSharedPreferences("agent", MODE_PRIVATE).edit().putString("last", message).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        // Итог показываем отдельным уведомлением.
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(ID + 1, Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_pause)
            .setContentTitle("ИИ-игрок остановлен")
            .setContentText(message)
            .setStyle(Notification.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .build())
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.aiplayer.app.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val DEFAULT_MODEL = "claude-sonnet-5-5"
        const val DEFAULT_OR_MODEL = "google/gemini-2.0-flash-exp:free"
        private const val CHANNEL = "agent"
        private const val ID = 7
    }
}

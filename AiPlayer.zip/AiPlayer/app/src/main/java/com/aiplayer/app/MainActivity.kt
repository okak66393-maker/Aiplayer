package com.aiplayer.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val BG = Color.parseColor("#10131C")
    private val CARD = Color.parseColor("#1A2030")
    private val ACCENT = Color.parseColor("#5CE1B0")
    private val TEXT = Color.parseColor("#EAF1FF")
    private val MUTED = Color.parseColor("#8E9BB8")

    private lateinit var keyBox: EditText
    private lateinit var modelBox: EditText
    private lateinit var goalBox: EditText
    private lateinit var stepsBox: EditText
    private lateinit var a11yStatus: TextView
    private lateinit var lastStatus: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("agent", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(36), dp(18), dp(28))
        }
        root.addView(label("ИИ-игрок", 28, TEXT, true))
        root.addView(label("Claude смотрит на экран и сам нажимает вместо тебя", 14, MUTED, false).apply { setPadding(0, 0, 0, dp(14)) })

        // Шаг 1
        root.addView(section("1. Доступ к нажатиям"))
        a11yStatus = label("", 14, MUTED, false)
        root.addView(a11yStatus)
        root.addView(button("Открыть настройки доступа") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Найди «ИИ-игрок (нажатия)» и включи", Toast.LENGTH_LONG).show()
        })

        // Шаг 2
        root.addView(section("2. Ключ Anthropic API"))
        keyBox = field("sk-ant-…", prefs.getString("key", ""), password = true)
        root.addView(keyBox)
        root.addView(label("Хранится только на этом телефоне. Модель:", 12, MUTED, false))
        modelBox = field(AgentService.DEFAULT_MODEL, prefs.getString("model", AgentService.DEFAULT_MODEL))
        root.addView(modelBox)

        // Шаг 3
        root.addView(section("3. Что делать в игре"))
        goalBox = field("Например: проходи уровни в игре, собирай награды, закрывай рекламу", prefs.getString("goal", ""), multiline = true)
        root.addView(goalBox)
        root.addView(label("Лимит шагов (на шаг уходит запрос к API):", 12, MUTED, false))
        stepsBox = field("150", prefs.getInt("steps", 150).toString(), number = true)
        root.addView(stepsBox)

        root.addView(button("▶  ЗАПУСТИТЬ", primary = true) { start() }.apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = dp(18)
        })
        root.addView(button("■  Остановить") {
            startService(Intent(this, AgentService::class.java).setAction(AgentService.ACTION_STOP))
        })
        lastStatus = label("", 13, MUTED, false).apply { setPadding(0, dp(10), 0, 0) }
        root.addView(lastStatus)
        root.addView(label("После нажатия есть 5 секунд, чтобы открыть игру. Остановить можно кнопкой СТОП в уведомлении.", 12, MUTED, false).apply { setPadding(0, dp(10), 0, 0) })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        val on = TapService.instance != null
        a11yStatus.text = if (on) "✓ Включено" else "✗ Выключено"
        a11yStatus.setTextColor(if (on) ACCENT else Color.parseColor("#FF8A80"))
        val last = getSharedPreferences("agent", MODE_PRIVATE).getString("last", "") ?: ""
        lastStatus.text = if (last.isEmpty()) "" else "Последний запуск: $last"
    }

    private fun start() {
        if (TapService.instance == null) { toast("Сначала включи доступ (шаг 1)"); return }
        if (keyBox.text.isBlank()) { toast("Вставь API-ключ"); return }
        if (goalBox.text.isBlank()) { toast("Напиши, что делать в игре"); return }
        getSharedPreferences("agent", MODE_PRIVATE).edit()
            .putString("key", keyBox.text.toString().trim())
            .putString("model", modelBox.text.toString().trim().ifEmpty { AgentService.DEFAULT_MODEL })
            .putString("goal", goalBox.text.toString().trim())
            .putInt("steps", stepsBox.text.toString().toIntOrNull()?.coerceIn(1, 2000) ?: 150)
            .apply()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode != RESULT_OK || data == null) { toast("Без разрешения на запись экрана ИИ ничего не увидит"); return }
        startForegroundService(
            Intent(this, AgentService::class.java)
                .putExtra(AgentService.EXTRA_CODE, resultCode)
                .putExtra(AgentService.EXTRA_DATA, data)
        )
        // Сворачиваем приложение, чтобы открыть игру.
        moveTaskToBack(true)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---- мелкие помощники UI ----

    private fun label(t: String, sp: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = t; textSize = sp.toFloat(); setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(2), 0, dp(2))
    }

    private fun section(t: String) = label(t, 16, ACCENT, true).apply { setPadding(0, dp(18), 0, dp(6)) }

    private fun field(hint: String, value: String?, password: Boolean = false, multiline: Boolean = false, number: Boolean = false) =
        EditText(this).apply {
            this.hint = hint
            setText(value ?: "")
            setTextColor(TEXT); setHintTextColor(MUTED); textSize = 14f
            background = GradientDrawable().apply { setColor(CARD); cornerRadius = dp(12).toFloat() }
            setPadding(dp(12), dp(10), dp(12), dp(10))
            inputType = when {
                password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                number -> InputType.TYPE_CLASS_NUMBER
                multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                else -> InputType.TYPE_CLASS_TEXT
            }
            if (multiline) { minLines = 3; gravity = Gravity.TOP }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(4) }
        }

    private fun button(t: String, primary: Boolean = false, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 15f
        setTextColor(if (primary) Color.parseColor("#06251A") else TEXT)
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply {
            setColor(if (primary) ACCENT else CARD); cornerRadius = dp(14).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    companion object { private const val REQ_CAPTURE = 42 }
}
